import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-under-dev',
  template: `<h2>Page Under Development</h2>`
})
export class UnderDevComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
