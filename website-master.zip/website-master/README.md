# Wejustdevelop
![alt text](https://scontent.fbog3-1.fna.fbcdn.net/v/t1.0-9/22046867_1846674398683745_8614146196819971947_n.jpg?oh=2dfb0365683b010f2cc7bafb233efe3d&oe=5AAB16D9)

Wejustdevelop is a platform to connect developers around the world. We guarantee we will always be a FREE service.

Our website is opensource! Get involved and we will add your profile as a contributor. Be sure to like our page and/or create pull requests! https://www.facebook.com/wejustdevelop 

Have a suggestion? Just create a new issue.

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 1.4.2.

# Website
Website: http://www.wejustdevelop.com

# Social Links
1. Facebook: https://www.facebook.com/wejustdevelop
2. Twitter: https://www.twitter.com/wejustdevelop
3. Linkedin: https://www.linkedin.com/company/wejustdevelop

## Contributing in #Hacktoberfest

1. You may start by adding your profile in CONTRIBUTORS.md

2. Solve some issue in https://github.com/wejustdevelop/website/issues

3. Like our facebook page: https://www.facebook.com/wejustdevelop

### Format

#### Name: [WeJustDevelop](https://github.com/wejustdevelop)
 - Place: Cebu, PH
 - Bio: Developing developers, paying it forward.
 - GitHub: [wejustdevelop](https://github.com/wejustdevelop)

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).
Before running the tests make sure you are serving the app via `ng serve`.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).

## Information

For more info please go to http://wejustdevelop.com/
#   W e b s i t e - m a s t e r -  
 "# website-master" 
