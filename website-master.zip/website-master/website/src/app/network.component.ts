import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-network',
  template: `<app-sidebar></app-sidebar>`
})
export class NetworkComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
