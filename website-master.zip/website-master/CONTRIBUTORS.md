
 [![We Just Develop](https://github.com/wejustdevelop.png?size=40 "WeJustDevelop")](https://github.com/wejustdevelop)
 - Place: Cebu, PH
 - Bio: Developing developers, paying it forward.
 - GitHub: [wejustdevelop](https://github.com/wejustdevelop)
 
 
 [![RamelEmbate](https://github.com/RamelEmbate.png?size=40 "RamelEmbate")](https://github.com/RamelEmbate)
 - Place: Philippines
 - Bio: Web developer
 - GitHub: [RamelEmbate](https://github.com/RamelEmbate)


[![Naldo](https://github.com/dpritos.png?size=40 "Naldo")](https://github.com/dpritos)
 - Place: Cebu, PH
 - Bio: Developing developers, paying it forward.
 - GitHub: [dpritos](https://github.com/dpritos)


[![Kavita](https://github.com/kavitaast.png?size=40 "Kavita")](https://github.com/kavitaast)
 - Place: India
 - Bio:
 - GitHub: [kavita](https://github.com/kavitaast)


 [![Michael Vinicio](https://github.com/vinird.png?size=40 "Michael Vinicio")](https://github.com/vinird)
 - Place: Costa Rica
 - Bio: Web developer and graphic designer.
 - GitHub: [vinird](https://github.com/vinird)

[![Disha Verma](https://github.com/dishaverma1.png?size=40 "Disha Verma")](https://github.com/dishaverma1)
 - Place: Udaipuur,Rajasthan
 - Bio: Android Developer, Front end and Backend developer.
 - GitHub: [dishaverma1](https://github.com/dishaverma1)


 [![TomEWilkinson](https://github.com/TomEWilKinson.png?size=40 "TomEWilkinson")](https://github.com/TomEWilkinson)
 - Place: United Kingdom
 - Bio:
 - GitHub: [TomEWilkinson](https://github.com/TomEWilkinson)


[![Jonathan Villarta](https://github.com/villartadh.png?size=40 "Jonathan Villarta")](https://github.com/villartadh)
 - Place: Philippines
 - Bio: Web developer
 - GitHub: [Jonathan Villarta](https://github.com/villartadh)

[![Richard Vergis](https://github.com/gahdada01.png?size=40 "Richard Vergis")](https://github.com/gahdada01)
 - Place: Cebu, Philippines
 - Bio: Full Stack Developer.
 - GitHub: [Mr. R](https://github.com/gahdada01)

[![Junmel Jayson](https://github.com/Junmel.png?size=40 "Junmel Jayson")](https://github.com/Junmel)
 - Place: Philippines
 - Bio: Web developer.
 - GitHub: [Junmel](https://github.com/Junmel)

[![Maurice Lacson](https://github.com/MauriceLacson.png?size=40 "Maurice Lacson")](https://github.com/MauriceLacson)
 - Place: Cebu, PH
 - Bio: Web Developer, Electronics/Semiconductor Technician
 - GitHub: [MauriceLacson](https://github.com/MauriceLacson)

 [![Nardo](https://github.com/nunezber31.png?size=40 "Nardo")](https://github.com/nunezber31)
 - Place: Cebu, PH
 - Bio: Developing developers, paying it forward.
 - GitHub: [nunezber31](https://github.com/nunezber31)

 [![Randy D. Binodo](https://github.com/binondord.png?size=40 "Randy D.Binodo")](https://github.com/binondord)
 - Place: Philippines
 - Bio: Coder. Trader. Handyman.
 - GitHub: [binondord](https://github.com/binoondord)
 
  [![Baile Anthony Escabillas](https://github.com/escabillas95.png?size=40 "Baile Anthony Escabillas")](https://github.com/escabillas95)
 - Place: Badian, Cebu Philippines 6032
 - Bio: Web Developer, IT admin, Web Designer
 - GitHub: [escabillas95](https://github.com/escabillas95)

 [![Amber Johnson](https://github.com/amberjohnsonsmile.png?size=40 "Amber Johnson")](https://github.com/amberjohnsonsmile)
 - Place: Fort Collins, CO, USA
 - Bio: Web Developer
 - GitHub: [amberjohnsonsmile](https://github.com/amberjohnsonsmile)

 [![Luan Carlos Araldi](https://github.com/LuanAraldi.png?size=40 "Luan Carlos Araldi")](https://github.com/LuanAraldi)
 - Place: Florianópolis, SC, BR
 - Bio: Web Developer
 - GitHub: [LuanAraldi](https://github.com/LuanAraldi)

 [![Noemi Hernandez](https://github.com/lelyhn.png?size=40 "Noemi Hernandez")](https://github.com/lelyhn)
 - Place: Oxnard, CA, USA
 - Bio: Student Web Developer
 - GitHub: [lelyhn](https://github.com/lelyhn)

 [![Darlene Zouras](https://github.com/darzouras.png?size=40 "Darlene Zouras")](https://github.com/darzouras)
 - Place: St. Louis, MO
 - Bio: Web Developer for marketing firm
 - GitHub: [darzouras](https://github.com/darzouras)

 [![Shivam Luthra](https://github.com/shivamluthra.png?size=40 "Shivam Luthra")](https://github.com/shivamluthra)
 - Place: Katra, J&K, India
 - Bio: Computer Science undergrad, Web Developer
 - GitHub: [shivamluthra](https://github.com/shivamluthra)

 [![Janice Medina](https://github.com/ConnectExtend.png?size=40 "Janice Medina")](https://github.com/ConnectExtend)
 - Place: Delavan, Wisconsin, USA
 - Bio: CodeNewbie, Aspiring Web Developer
 - GitHub: [ConnectExtend](https://github.com/ConnectExtend)

 [![Sumit Agarwal](https://github.com/sumiet.png?size=40 "Sumit Agarwal")](https://github.com/sumiet)
 - Place: Hyderabad, India
 - Bio: Computer Science undergrad, Web Developer
 - GitHub: [sumiet](https://github.com/sumiet)

 [![Sameer Sengar](https://github.com/sengarsameer.png?size=40 "Sameer Sengar")](https://github.com/sengarsameer)
 - Place: J&K, India
 - Bio: Computer Science undergrad at SMVD University.
 - GitHub: [sengarsameer](https://github.com/sengarsameer)

 [![Kulan Sachinthana](https://github.com/KulanS.png?size=40 "Kulan Sachinthana")](https://github.com/KulanS)
 - Place: Colombo, Sri Lanka
 - Bio: Student, Computer Science
 - GitHub: [KulanS](https://github.com/KulanS)

 [![Tom Kennedy](https://github.com/tomkennedycode.png?size=40 "Tom Kennedy")](https://github.com/tomkennedycode)
 - Place: London, England
 - Bio: Junior Web Developer
 - GitHub: [tomkennedycode](https://github.com/tomkennedycode)

  [![Pierre Cambrin](https://github.com/arda971.png?size=40 "Pierre Cambrin")](https://github.com/arda971)
 - Place: Guadeloupe, France
 - Bio: Web Developer
 - GitHub: [arda971](https://github.com/arda971)

 [![Fanny Chien](https://github.com/fc2.png?size=40 "Fanny Chien")](https://github.com/fc2)
- Place: Recife, Brazil
- Bio: Computer Science undergrad
- GitHub: [fc2](https://github.com/fc2)
